Drop player.tscn into a scene.

For an example scene, check examples/first_person_starter_test.tscn
